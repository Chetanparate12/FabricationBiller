document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('billForm');
    const addItemBtn = document.getElementById('addItemBtn');
    const itemsContainer = document.getElementById('itemsContainer');
    const successModal = new bootstrap.Modal(document.getElementById('successModal'));
    const downloadPdfBtn = document.getElementById('downloadPdfBtn');

    // Set today's date as default
    document.querySelector('input[name="date"]').valueAsDate = new Date();

    addItemBtn.addEventListener('click', function() {
        const newRow = document.querySelector('.item-row').cloneNode(true);
        newRow.querySelectorAll('input').forEach(input => {
            input.value = '';
        });
        itemsContainer.appendChild(newRow);
        setupItemListeners(newRow);
    });

    function setupItemListeners(row) {
        const value = row.querySelector('.item-value');
        const rate = row.querySelector('.item-rate');
        const amount = row.querySelector('.item-amount');
        const unit = row.querySelector('.item-unit');

        function calculateAmount() {
            if (!value || !rate || !amount) return;
            const val = parseFloat(value.value) || 0;
            const rt = parseFloat(rate.value) || 0;
            amount.value = (val * rt).toFixed(2);
            calculateTotal();
        }

        if (value) value.addEventListener('input', calculateAmount);
        if (rate) rate.addEventListener('input', calculateAmount);
    }

    function calculateTotal() {
        let total = 0;
        document.querySelectorAll('.item-amount').forEach(amount => {
            total += parseFloat(amount.value) || 0;
        });

        document.getElementById('total').textContent = `₹${total.toFixed(2)}`;

        // Update paid amount max value
        const paidAmountInput = form.querySelector('[name="paidAmount"]');
        paidAmountInput.max = total;
    }

    // Setup initial row
    setupItemListeners(document.querySelector('.item-row'));

    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const items = [];
        document.querySelectorAll('.item-row').forEach(row => {
            items.push({
                description: row.querySelector('.item-description').value,
                quantity: parseFloat(row.querySelector('.item-value').value),
                rate: parseFloat(row.querySelector('.item-rate').value),
                amount: parseFloat(row.querySelector('.item-amount').value)
            });
        });

        const total = parseFloat(document.getElementById('total').textContent.replace('₹', ''));
        const paidAmount = parseFloat(form.querySelector('[name="paidAmount"]').value) || 0;

        // Calculate payment status
        let paymentStatus = 'pending';
        if (paidAmount >= total) {
            paymentStatus = 'paid';
        } else if (paidAmount > 0) {
            paymentStatus = 'partial';
        }

        const billData = {
            customerName: form.querySelector('[name="customerName"]').value,
            phoneNumber: form.querySelector('[name="phoneNumber"]').value,
            date: form.querySelector('[name="date"]').value,
            items: items,
            subtotal: total,
            total: total,
            paidAmount: paidAmount,
            paymentStatus: paymentStatus
        };

        fetch('/generate_bill', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(billData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                downloadPdfBtn.href = `/download_pdf/${data.bill_id}`;
                successModal.show();
            } else {
                alert('Error generating bill: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error generating bill');
        });
    });
});