document.addEventListener('DOMContentLoaded', function() {
    // Add payment edit modal to the page
    const modalHtml = `
        <div class="modal fade" id="editPaymentModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Update Payment</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Total Amount: <span id="totalAmount"></span></label>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Current Paid Amount: <span id="currentPaid"></span></label>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Remaining Balance: <span id="remainingBalance"></span></label>
                        </div>
                        <div class="mb-3">
                            <label for="paidAmount" class="form-label">New Payment Amount:</label>
                            <input type="number" class="form-control" id="paidAmount" step="0.01">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-warning" id="payRemaining">Pay Remaining</button>
                        <button type="button" class="btn btn-primary" id="savePayment">Save Payment</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    const editPaymentModal = new bootstrap.Modal(document.getElementById('editPaymentModal'));

    // Handle edit payment button clicks
    document.querySelectorAll('.edit-payment').forEach(button => {
        button.addEventListener('click', function() {
            const billId = this.dataset.billId;
            const total = parseFloat(this.dataset.total);
            const paid = parseFloat(this.dataset.paid);
            const remaining = total - paid;
            
            document.getElementById('totalAmount').textContent = `₹${total.toFixed(2)}`;
            document.getElementById('currentPaid').textContent = `₹${paid.toFixed(2)}`;
            document.getElementById('remainingBalance').textContent = `₹${remaining.toFixed(2)}`;
            document.getElementById('paidAmount').value = '';
            document.getElementById('paidAmount').max = remaining;
            
            const payRemainingBtn = document.getElementById('payRemaining');
            const saveBtn = document.getElementById('savePayment');
            
            payRemainingBtn.onclick = () => {
                document.getElementById('paidAmount').value = remaining.toFixed(2);
            };
            
            saveBtn.onclick = async () => {
                const newPaidAmount = document.getElementById('paidAmount').value;
                
                try {
                    const response = await fetch(`/update_payment/${billId}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ paid_amount: newPaidAmount })
                    });
                    
                    const data = await response.json();
                    if (data.success) {
                        window.location.reload();
                    } else {
                        alert('Error updating payment: ' + data.error);
                    }
                } catch (error) {
                    console.error('Error:', error);
                    alert('Error updating payment');
                }
            };
            
            editPaymentModal.show();
        });
    });
    const tbody = document.querySelector('tbody');
    const rows = tbody.querySelectorAll('tr');
    let sortDirection = {};

    const nameSearch = document.getElementById('nameSearch');
    const statusFilter = document.getElementById('statusFilter');
    const searchBtn = document.getElementById('searchBtn');

    // Delete bill functionality
    document.querySelectorAll('.delete-bill').forEach(button => {
        button.addEventListener('click', async function() {
            if (confirm('Are you sure you want to delete this bill?')) {
                const billId = this.dataset.billId;
                try {
                    const response = await fetch(`/delete_bill/${billId}`, {
                        method: 'DELETE'
                    });

                    if (response.ok) {
                        this.closest('tr').remove();
                    } else {
                        alert('Error deleting bill');
                    }
                } catch (error) {
                    console.error('Error:', error);
                    alert('Error deleting bill');
                }
            }
        });
    });

    function filterTable() {
        const searchTerm = nameSearch.value.toLowerCase();
        const statusTerm = statusFilter.value.toLowerCase();

        rows.forEach(row => {
            const customerName = row.cells[2].textContent.toLowerCase();
            const status = row.cells[6].textContent.trim().toLowerCase();

            const nameMatch = customerName.includes(searchTerm);
            const statusMatch = !statusTerm || status.includes(statusTerm);

            row.style.display = (nameMatch && statusMatch) ? '' : 'none';
        });
    }

    searchBtn.addEventListener('click', filterTable);
    nameSearch.addEventListener('keyup', function(e) {
        if (e.key === 'Enter') filterTable();
    });
    statusFilter.addEventListener('change', filterTable);

    document.querySelectorAll('.sort-btn').forEach(button => {
        button.addEventListener('click', function() {
            const sortKey = this.dataset.sort;
            const icon = this.querySelector('i');

            sortDirection[sortKey] = !sortDirection[sortKey];

            icon.className = sortDirection[sortKey] ? 
                'bi bi-sort-alpha-up' : 
                'bi bi-sort-alpha-down';

            const rows = Array.from(tbody.querySelectorAll('tr'));

            rows.sort((a, b) => {
                let aValue, bValue;

                if (sortKey === 'customer') {
                    aValue = a.cells[2].textContent.trim();
                    bValue = b.cells[2].textContent.trim();
                } else if (sortKey === 'status') {
                    aValue = a.cells[6].textContent.trim();
                    bValue = b.cells[6].textContent.trim();
                }

                if (sortDirection[sortKey]) {
                    return aValue.localeCompare(bValue);
                } else {
                    return bValue.localeCompare(aValue);
                }
            });

            rows.forEach(row => tbody.appendChild(row));
        });
    });
});