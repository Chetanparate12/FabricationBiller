import os
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

def generate_pdf(bill_data):
    pdf_path = os.path.join(os.getcwd(), "pdfs", f"{bill_data['id']}.pdf")
    doc = SimpleDocTemplate(
        pdf_path,
        pagesize=letter,
        rightMargin=72,
        leftMargin=72,
        topMargin=72,
        bottomMargin=72
    )

    # Prepare story (content) for the PDF
    story = []
    styles = getSampleStyleSheet()

    # Add company header
    header_style = ParagraphStyle(
        'CustomHeader',
        parent=styles['Heading1'],
        fontSize=24,
        spaceAfter=30
    )
    story.append(Paragraph("Fabrication Bill", header_style))

    # Add customer info
    story.append(Paragraph(f"<b>Customer:</b> {bill_data['customerName']}", styles['Normal']))
    story.append(Paragraph(f"<b>Phone:</b> {bill_data['phoneNumber']}", styles['Normal']))
    story.append(Paragraph(f"<b>Date:</b> {bill_data['date']}", styles['Normal']))
    story.append(Spacer(1, 20))

    # Create items table with serial numbers
    table_data = [['S.No', 'Description', 'Length', 'Width', 'Quantity', 'Rate', 'Amount']]
    for idx, item in enumerate(bill_data['items'], 1):
        # Split description into parts if it contains dimensions
        desc_parts = item['description'].split(' - ')
        desc = desc_parts[0]
        length = ''
        width = ''
        if len(desc_parts) > 1:
            dims = desc_parts[1].split('x')
            if len(dims) == 2:
                length, width = dims
        
        table_data.append([
            str(idx),
            desc,
            length,
            width,
            str(item['quantity']),
            f"₹{item['rate']:.2f}",
            f"₹{item['amount']:.2f}"
        ])

    # Add payment details with right alignment
    payment_data = [
        ['', '', '', '', '', 'Subtotal:', f"₹{bill_data['subtotal']:.2f}"],
        ['', '', '', '', '', 'Total:', f"₹{bill_data['total']:.2f}"],
        ['', '', '', '', '', 'Paid Amount:', f"₹{bill_data['paid_amount']:.2f}"],
        ['', '', '', '', '', 'Pending Amount:', f"₹{bill_data['pending_amount']:.2f}"]
    ]
    table_data.extend(payment_data)

    # Style the table with adjusted column widths
    table = Table(table_data, colWidths=[0.5*inch, 3*inch, 0.8*inch, 0.8*inch, 0.8*inch, 1*inch, 1*inch])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -5), colors.white),
        ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
        ('ALIGN', (0, 0), (0, -5), 'CENTER'),  # Center S.No
        ('ALIGN', (4, 1), (-1, -1), 'RIGHT'),  # Right align numbers
        ('ALIGN', (1, 1), (1, -5), 'LEFT'),    # Left align description
        ('GRID', (0, 0), (-1, -5), 1, colors.black),
        ('FONTNAME', (-2, -4), (-1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (-2, -4), (-1, -1), 12),
    ]))

    story.append(table)

    # Add payment status
    story.append(Spacer(1, 20))
    status_style = ParagraphStyle(
        'Status',
        parent=styles['Normal'],
        fontSize=12,
        textColor=colors.red if bill_data['payment_status'] == 'pending' else 
                 colors.orange if bill_data['payment_status'] == 'partial' else 
                 colors.green
    )
    story.append(Paragraph(f"Payment Status: {bill_data['payment_status'].title()}", status_style))

    # Add footer
    story.append(Spacer(1, 30))
    story.append(Paragraph("Thank you for your business!", styles['Normal']))

    # Build PDF
    doc.build(story)
    return pdf_path